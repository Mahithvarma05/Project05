package Methods;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Scanner;

import pojoClass.pojo;


public class EmpDaoImpl {
	Scanner sc=new Scanner(System.in);
	public Connection getDb() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/empdb","root","root");  		
		return con;
		
	}

	DBConnection dbConnection=new DBConnection();
	public void createEmployee(pojo emp) {
	Connection con=DBConnection.creatDBConnection();
	String type=emp.getType();
	String query="insert into employee values(?,?,?,?)";
	PreparedStatement pstmt=null;
	int cnt1;
	PreparedStatement pstmt2=null;
		try {
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1, emp.getId());
			pstmt.setString(2, emp.getName());
			pstmt.setDouble(3, emp.getSalary());
			pstmt.setString(4, emp.getType());
			int cnt=pstmt.executeUpdate();
			if(cnt!=0) {
				System.out.println("Updated successfully");
			}
			
		String queryp;
		
		switch(type) {
		
		case "permanent":
			queryp="insert into permanent values(?,?)";
			pstmt2=con.prepareStatement(queryp);
			pstmt2.setInt(1, emp.getId());
			pstmt2.setString(2, emp.getName());
			cnt1=pstmt2.executeUpdate();
			if(cnt1!=0) {
				System.out.println("Updated successfully");
			}
			break;
		case "parttime":
			queryp="insert into parttime values(?,?)";
			pstmt2=con.prepareStatement(queryp);
			pstmt2.setInt(1, emp.getId());
			pstmt2.setString(2, emp.getName());
			cnt1=pstmt2.executeUpdate();
			if(cnt1!=0) {
				System.out.println("Updated successfully");
			}
			break;
		case "contract":
			queryp="insert into contract values(?,?)";
			pstmt2=con.prepareStatement(queryp);
			pstmt2.setInt(1, emp.getId());
			pstmt2.setString(2, emp.getName());
			cnt1=pstmt2.executeUpdate();
			if(cnt1!=0) {
				System.out.println("Updated successfully");
			}
			break;
			
		}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstmt.close();
				pstmt2.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		}
	public void modify(pojo emp) {
		Connection con=DBConnection.creatDBConnection();
		
			int id=emp.getId();
			String type=emp.getType();
			
			PreparedStatement pstmt5=null;
			String query="update employee set name=? where id=?";
			
			try {
				 pstmt5=con.prepareStatement(query);
				pstmt5.setString(1, emp.getName());
				pstmt5.setInt(2, id);
				int cnt=pstmt5.executeUpdate();
				if(cnt!=0) {
					System.out.println("Updated successfully");
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt5.close();
					
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			
	
			String query2="update employee set salary=? where id=?";
			PreparedStatement pstmt6=null;
			try {
				pstmt6=con.prepareStatement(query2);
				pstmt6.setDouble(1, emp.getSalary());
				pstmt6.setInt(2, id);
				int cnt=pstmt6.executeUpdate();
				if(cnt!=0) {
					System.out.println("Updated successfully");
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt6.close();
				
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			 
			String query3="update employee set type=? where id=?";
			PreparedStatement pstmt7=null;
			try {
				pstmt7=con.prepareStatement(query3);
				pstmt7.setString(1, emp.getType());
				pstmt7.setInt(2, id);
				int cnt=pstmt7.executeUpdate();
				if(cnt!=0) {
					System.out.println("Updated successfully");
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt7.close();
					
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			if(type.equals("permanent")) {
				String queryp="update permanent set name=? where id=?";
				PreparedStatement pstmt8=null;
				try {
					 pstmt8=con.prepareStatement(queryp);
					pstmt8.setString(1, emp.getName());
					pstmt8.setInt(2, emp.getId());
					int cnt=pstmt8.executeUpdate();
					if(cnt!=0) {
						System.out.println("Updated successfully");
					}
					
				}catch (SQLException e) {
					e.printStackTrace();
				}
				finally {
					try {
						pstmt8.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
				}
				
				
			}
			if(type.equals("parttime")) {
				String querypt="update parttime set name=? where id=?";
				PreparedStatement pstmt9=null;
				try {
					 pstmt9=con.prepareStatement(querypt);
					pstmt9.setString(1, emp.getName());
					pstmt9.setInt(2, emp.getId());
					int cnt=pstmt9.executeUpdate();
					if(cnt!=0) {
						System.out.println("Updated successfully");
					}
					
				}catch (SQLException e) {
					e.printStackTrace();
				}
				finally {
					try {
						pstmt9.close();
					} catch (SQLException e) {
					
						e.printStackTrace();
					}
				}
				
			}
			if(type.equals("contract")) {
				String queryc="update contract set name=? where id=?";
				PreparedStatement pstmt10=null;
				try {
					pstmt10=con.prepareStatement(queryc);
					pstmt10.setString(1, emp.getName());
					pstmt10.setInt(2, emp.getId());
					int cnt=pstmt10.executeUpdate();
					if(cnt!=0) {
						System.out.println("Updated successfully");
					}
				}catch (SQLException e) {
					e.printStackTrace();
				}
				finally {
					try {
						pstmt10.close();
						con.close();
					} catch (SQLException e) {
		
						e.printStackTrace();
					}
				}
			}
			
    		
		}		
	

	public void delete(String type,int id) {
		Connection con=DBConnection.creatDBConnection();
		String query="delete from employee where id=?";
		PreparedStatement pstmt11=null;
		try {
			 pstmt11 = con.prepareStatement(query);
			pstmt11.setInt(1, id);
			int cnt=pstmt11.executeUpdate();
			if(cnt!=0) {
				System.out.println("deleted successfully");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstmt11.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if(type.equals("permanent")) {
			String queryp="delete from permanent where id=?";
			PreparedStatement pstmt12=null;
			try {
				pstmt12 = con.prepareStatement(queryp);
				pstmt12.setInt(1, id);
				int cnt=pstmt12.executeUpdate();
				if(cnt!=0) {
					System.out.println("deleted successfully");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt12.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
						
		}
		if(type.equals("parttime")) {
			String querypt="delete from parttime where id=?";
			PreparedStatement pstmt13=null;
			try {
				pstmt13 = con.prepareStatement(querypt);
				pstmt13.setInt(1, id);
				int cnt=pstmt13.executeUpdate();
				if(cnt!=0) {
					System.out.println("deleted successfully");
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt13.close();
				} catch (SQLException e) {
	
					e.printStackTrace();
				}
			}
			
			
		}
		if(type.equals("contract")) {
			String queryc="delete from contract where id=?";
			PreparedStatement pstmt14=null;
			try {
				pstmt14 = con.prepareStatement(queryc);
				pstmt14.setInt(1, id);
				int cnt=pstmt14.executeUpdate();
				if(cnt!=0) {
					System.out.println("deleted successfully");
					
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt14.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
	
		}
		
	}
		
	
	public void viewEmp() {
		Connection con=DBConnection.creatDBConnection();
		String query="select * from employee";	
		Statement pstmt15=null;
			try {
				pstmt15=con.createStatement();
				ResultSet result=pstmt15.executeQuery(query);
				while(result.next()) {
					System.out.println("Employee id - "+ result.getInt(1)+" Employee Name - "+result.getString(2)+" Employee Salary- "+result.getDouble(3)+" Employee Type - "+result.getString(4));
				
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					pstmt15.close();
				} catch (SQLException e) {
	
					e.printStackTrace();
				}
			}
							
	}
	public Hashtable<Integer,pojo> viewJSON() {
		Connection con=DBConnection.creatDBConnection();
		PreparedStatement pstmt16=null;
		Hashtable<Integer, pojo> hMap=new Hashtable<Integer, pojo>();
		try {
			pstmt16 = con.prepareStatement("select * from employee");
		
		   ResultSet rs=pstmt16.executeQuery();   		 
//		   JSONArray employeeArray=new JSONArray();
		   while(rs.next()) {
			   pojo e=new pojo(rs.getInt("id"), rs.getString("name"), rs.getDouble("id"), rs.getString("type"));
			   hMap.put(rs.getInt("id"), e);
			   
//			    JSONObject empy=new JSONObject(); 
//			     
//			    empy.put("empId",rs.getInt("id"));
//		        empy.put("empName",rs.getString("name"));
//		        empy.put("empSalary",rs.getDouble("salary"));
//		        empy.put("empType",rs.getString("type"));
//		  
//		        employeeArray.put(empy);
		        
		   }  	
//		   System.out.println(employeeArray);
	}catch (SQLException e) {
		e.printStackTrace();
	}
		finally {
			try {
				pstmt16.close();
				con.close();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
		}
		return hMap;
		
	
	}
	
	
	public Hashtable<Integer,pojo> viewJSON(int id)  {
		
		PreparedStatement pstmt16=null;
		Hashtable<Integer, pojo> hMap=new Hashtable<Integer, pojo>();
		try {
			Connection con=getDb();
			String q="select * from employee where id=?";
			pstmt16 = con.prepareStatement(q);
			pstmt16.setInt(1, id);		
			ResultSet rs=pstmt16.executeQuery();   
//		   JSONArray employeeArray=new JSONArray();
		   System.out.println("in while");

		   while(rs.next()) {
			   pojo e=new pojo(rs.getInt("id"), rs.getString("name"), rs.getDouble("salary"), rs.getString("type"));
			   hMap.put(rs.getInt("id"), e);
			   
//			    JSONObject empy=new JSONObject(); 
//			     
//			    empy.put("empId",rs.getInt("id"));
//		        empy.put("empName",rs.getString("name"));
//		        empy.put("empSalary",rs.getDouble("salary"));
//		        empy.put("empType",rs.getString("type"));
//		  
//		        employeeArray.put(empy);

		   }
		   return hMap;
//		   System.out.println(employeeArray);
	}catch (SQLException e) {
		e.printStackTrace();
	} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		finally {
			try {
				pstmt16.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return hMap;
		
	
	}
	
	
	
//	public void exitDB() {
//			try {
//				DBConnection.creatDBConnection().close();
//				} catch (SQLException e) {
//					e.printStackTrace();
//					}
//			}
			 
	

	
}
